package com.cg.appl.controllers;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;

import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.validation.BindingResultUtils;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.appl.entities.Trainee;
import com.cg.appl.exceptions.TraineeException;
import com.cg.appl.services.TraineeService;
import com.sun.xml.internal.org.jvnet.staxex.NamespaceContextEx.Binding;

//http://localhost:8085/Spring120MVC_Login/login.jsp
@Controller
public class TraineeCrudController {
	private TraineeService services;
	private List<String> domainList;
	private List<String> locations;
	
	
	@Resource(name="traineeService")
	public void setTraineeServices(TraineeService services)
		{
			this.services = services;
		}
	
	@PostConstruct
	public void intialize(){
		domainList = new ArrayList<>();
		domainList.add("Java");
		domainList.add(".NET");
		domainList.add("Database");
		domainList.add("Analytics");
		
		locations= new ArrayList<>();
		locations.add("Mumbai");
		locations.add("Bengaluru");
		locations.add("Mangalore");
		locations.add("Goa");
		locations.add("Pune");
	}
	
	
		//Give login.jsp
	@RequestMapping("/welcome.do")
	public ModelAndView getWelcomePage(){
		ModelAndView model = new ModelAndView("welcome");
		return model;
	}
	
	@RequestMapping("/enterTraineeNo.do")	
	public ModelAndView showLoginPage(){
			
			ModelAndView model = new ModelAndView("login");
			return model;
			
		}
	
	
	
		//Do authentication
	@RequestMapping("/getTraineeDetails.do")
	public ModelAndView getEmpDetails(@RequestParam("traineeid") int traineeid){
		System.out.println(traineeid);
		ModelAndView model= null;
		try {
			Trainee trainee = services.getTraineeDetails(traineeid);
			model = new ModelAndView("traineeDetails");
			model.addObject("traineeDetails", trainee);
		} catch (TraineeException e) {
			model= new ModelAndView("error");
			model.addObject("errmsg",e.getMessage());
		}
		
		
	
		return model;
			
	}
	
	@RequestMapping("/listAllTrainee.do")
	public ModelAndView listAllTrainees(){
		
		ModelAndView model= null;
		try {
			List<Trainee> trainees = services.getAllTrainees();
			model = new ModelAndView("allTraineeDetails");
			model.addObject("allTraineeDetails", trainees);
		} catch (TraineeException e) {
			model= new ModelAndView("error");
			model.addObject("errmsg",e.getMessage());
		}
		return model;
		
	}
	
	@RequestMapping("/entryForm.do")
	public ModelAndView getEntryForm(){
		
		ModelAndView model = new ModelAndView("entryForm");
		model.addObject("trainee", new Trainee());
		model.addObject("domains", domainList);
		model.addObject("locations", locations);
		return model;
	}
	
	@RequestMapping("/submitEntryForm.do")
	public ModelAndView submitEntryForm(@ModelAttribute @Valid Trainee trainee, BindingResult result){
		ModelAndView model= new ModelAndView();
		
		if(result.hasErrors())
		{
			model.setViewName("entryForm");
			
			model.addObject("domains", domainList);
			model.addObject("locations", locations);
			return model;
		}
		
		try {
			Trainee traineeResponse = services.insertNewTrainee(trainee);

			model.setViewName("successInsert");
			model.addObject("traineeResponse", traineeResponse);
			
		} catch (TraineeException e) {
			
			model= new ModelAndView("error");
			model.addObject("errmsg", "Record insertion failed: " + e.getMessage());
		}
		return model;
	}
	
		//Show main menu or show login page again.
	
	@RequestMapping("/updateTrainee.do")
	public ModelAndView updateTrainee(@RequestParam("id")int traineeid){
		System.out.println(traineeid);
		ModelAndView model= null;
		model= new ModelAndView("error");
		model.addObject("errmsg","Dummy message");
		/*try {
			Trainee trainee = services.getTraineeDetails(traineeid);
			model = new ModelAndView("traineeDetails");
			model.addObject("traineeDetails", trainee);
		} catch (TraineeException e) {
			model= new ModelAndView("error");
			model.addObject("errmsg",e.getMessage());
		}*/
		
		
	
		return model;
			
	}
	
}
