package com.cg.appl.services;

import java.util.List;

import javax.annotation.Resource;
import javax.transaction.Transactional;

import org.springframework.stereotype.Service;

import com.cg.appl.entities.Trainee;
import com.cg.appl.daos.TraineeDao;
import com.cg.appl.exceptions.TraineeException;

@Service("traineeService")
public class TraineeServiceImpl implements TraineeService {
	private TraineeDao dao;
	
	@Resource(name="traineeDao")
	public void setTraineeDao(TraineeDao dao){
		this.dao=dao;
	}
	
	@Override
	public Trainee getTraineeDetails(int traineeId) throws TraineeException {
	
		return dao.getTraineeDetails(traineeId);
	}

	@Override
	public List<Trainee> getAllTrainees() throws TraineeException {
		
		return dao.getAllTrainees();
	}
	
	
	//@Transactional
	@Override
	public Trainee insertNewTrainee(Trainee trainee) throws TraineeException {
		
		return dao.insertNewTrainee(trainee);
	}

}
