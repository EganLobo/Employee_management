package com.cg.appl.services;

import java.util.List;

import com.cg.appl.entities.Trainee;
import com.cg.appl.exceptions.TraineeException;

public interface TraineeService {

	Trainee getTraineeDetails(int traineeId) throws TraineeException;
	List<Trainee> getAllTrainees() throws TraineeException;
	Trainee insertNewTrainee(Trainee trainee) throws TraineeException;
}
