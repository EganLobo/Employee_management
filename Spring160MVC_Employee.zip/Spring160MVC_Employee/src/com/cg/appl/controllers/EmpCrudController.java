package com.cg.appl.controllers;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.BindingResultUtils;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.appl.entities.Emp;
import com.cg.appl.exceptions.EmpException;
import com.cg.appl.services.EmpService;

//http://localhost:8085/Spring120MVC_Login/login.jsp
@Controller
public class EmpCrudController {
	private EmpService services;
	
	
	
	@Resource(name="empService")
	public void setTraineeServices(EmpService services)
		{
			this.services = services;
		}
	
	/*@PostConstruct
	public void intialize(){
		domainList = new ArrayList<>();
		domainList.add("Java");
		domainList.add(".NET");
		domainList.add("Database");
		domainList.add("Analytics");
		
		locations= new ArrayList<>();
		locations.add("Mumbai");
		locations.add("Bengaluru");
		locations.add("Mangalore");
		locations.add("Goa");
		locations.add("Pune");
	}*/
	
	
		//Give login.jsp
	@RequestMapping("/welcome.do")
	public ModelAndView getWelcomePage(){
		ModelAndView model = new ModelAndView("welcome");
		return model;
	}
	
	@RequestMapping("/enterEmpNo.do")	
	public ModelAndView showLoginPage(){
			System.out.println("In controlling method");
			ModelAndView model = new ModelAndView("enterEmpNo");
			return model;
			
		}
	
	
	
		//Do authentication
	@RequestMapping("/getEmpDetails.do")
	public ModelAndView getEmpDetails(@RequestParam("empNo") int empNo){
		System.out.println(empNo);
		ModelAndView model= null;
		try {
			Emp emp = services.getEmpDetails(empNo);
			model = new ModelAndView("empDetails");
			model.addObject("empDetails", emp);
		} catch (EmpException e) {
			model= new ModelAndView("error");
			model.addObject("errmsg",e.getMessage());
		}
		
		
	
		return model;
			
	}
	
	@RequestMapping("/listAllEmps.do")
	public ModelAndView listAllTrainees(){
		
		ModelAndView model= null;
		try {
			List<Emp> emp = services.getAllEmp();
			model = new ModelAndView("allEmpDetails");
			model.addObject("allEmpDetails", emp);
		} catch (EmpException e) {
			model= new ModelAndView("error");
			model.addObject("errmsg",e.getMessage());
		}
		return model;
		
	}
	
	@RequestMapping("/updateForm.do")
	public ModelAndView getUpdateForm(@RequestParam("id") int empNo){
		ModelAndView model=null;
		try {
			Emp emp=services.getEmpDetails(empNo);
			model = new ModelAndView("updateForm");
			model.addObject("emp", emp);
			
		} catch (EmpException e) {
			model= new ModelAndView("error");
			model.addObject("errmsg",e.getMessage());
		}
		return model;
	}
	
	@RequestMapping("/submitUpdateForm.do")
	public ModelAndView submitUpdateForm(@ModelAttribute("emp") @Valid Emp emp, BindingResult result, ModelAndView model){
		
		
		if(result.hasErrors())
		{
			System.out.println(result.getAllErrors());
			model.addObject("emp", emp);
			model.setViewName("updateForm");
			return model;
		}
		
		try {
			Emp empResponse = services.updateEmp(emp);
			model.addObject("empDetails", empResponse);
			model.setViewName("successUpdate");
			
		} catch (EmpException e) {
			
			model= new ModelAndView("error");
			model.addObject("errmsg", "Record insertion failed: " + e.getMessage());
		}
		return model;
	}
	
	@RequestMapping("/insertEmpDetails.do")
	public ModelAndView insertEmpDetails(){
		
		ModelAndView model = new ModelAndView("insertEmp");
		Emp e = new Emp();
		model.addObject("emp", e);
		return model;
	}
	
	
	@RequestMapping("/submitInsertForm.do")
	public ModelAndView submitinsertForm(@ModelAttribute("emp") @Valid Emp emp, BindingResult result){
		ModelAndView model= new ModelAndView("successInsert");
		
		if(result.hasErrors())
		{	
			model.setViewName("insertEmp");
			return model;
		
		}
		
		try {
			Emp empResponse = services.insertNewEmp(emp);
			System.out.println("in here");
			//model.setViewName("successInsert");
			
			
		} catch (EmpException e) {
			
			model= new ModelAndView("error");
			model.addObject("errmsg", "Record insertion failed: " + e.getMessage());
		}
		return model;
	}
	
	
	@RequestMapping("/deleteForm.do")
	public ModelAndView deleteUser(@RequestParam("id") int empId){
		ModelAndView model=null;
		try {
			boolean emp=services.deleteNewEmp(empId);
			model = new ModelAndView("successDelete");
			
			
		} catch (EmpException e) {
			model= new ModelAndView("error");
			model.addObject("errmsg",e.getMessage());
		}
		return model;
	}
	
	
	
	
	
	
	
		//Show main menu or show login page again.
	
/*	@RequestMapping("/updateTrainee.do")
	public ModelAndView updateTrainee(@RequestParam("id")int traineeid){
		System.out.println(traineeid);
		ModelAndView model= null;
		model= new ModelAndView("error");
		model.addObject("errmsg","Dummy message");
		try {
			Trainee trainee = services.getTraineeDetails(traineeid);
			model = new ModelAndView("traineeDetails");
			model.addObject("traineeDetails", trainee);
		} catch (TraineeException e) {
			model= new ModelAndView("error");
			model.addObject("errmsg",e.getMessage());
		}
		
		
	
		return model;
			
	}*/
	
}
