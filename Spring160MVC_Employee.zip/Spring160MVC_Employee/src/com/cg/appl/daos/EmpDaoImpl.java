package com.cg.appl.daos;


import java.util.List;

import javax.annotation.Resource;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.RollbackException;

import org.springframework.stereotype.Repository;

import com.cg.appl.entities.Emp;
import com.cg.appl.exceptions.EmpException;


@Repository("empDao")
public class EmpDaoImpl implements EmpDao {
	@PersistenceContext
	private EntityManager manager;
	
/*	@Resource(name="entityMFactory")
	public void setEntityManagerFactory(EntityManagerFactory factory){
		this.factory = factory;
	}*/
	
	
	/*@Override
	public Trainee insertNewTrainee(Trainee trainee) throws TraineeException {
		EntityManager manager= factory.createEntityManager();
		try {
			System.out.println(trainee);
			EntityTransaction trans = manager.getTransaction();
			trans.begin();
			manager.persist(trainee); //inserting
			trans.commit();
			
		} catch (RollbackException e) {
			throw new TraineeException("Record not committed", e);
		}
		
		return trainee;
	}*/

	@Override
	public Emp getEmpDetails(int empId) throws EmpException {
	
		Emp emp= manager.find(Emp.class, empId);
		return emp;
		
	}

	@Override
	public List<Emp> getAllEmp() throws EmpException {
	
		Query qry= manager.createNamedQuery("qryAllEmps", Emp.class);
		return qry.getResultList();
		
	}

	@Override
	public Emp updateEmp(Emp emp) throws EmpException, RollbackException {
		//EntityManager manager= factory.createEntityManager();
		
		manager.merge(emp);
		
		return emp;
	}
	
	@Override
	public Emp insertNewEmp(Emp emp) throws EmpException, RollbackException {
			
			manager.persist(emp); //inserting
			return emp;
	}

	@Override
	public boolean deleteNewEmp(int empId) throws EmpException, RollbackException {
		
		Emp emp = this.getEmpDetails(empId);
		manager.remove(emp);
		return true;
	}
}
