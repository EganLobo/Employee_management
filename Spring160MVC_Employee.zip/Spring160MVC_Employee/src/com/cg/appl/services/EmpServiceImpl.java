package com.cg.appl.services;

import java.util.List;

import javax.annotation.Resource;
import javax.persistence.RollbackException;



import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cg.appl.daos.EmpDao;
import com.cg.appl.entities.Emp;
import com.cg.appl.exceptions.EmpException;

@Service("empService")
@Transactional
public class EmpServiceImpl implements EmpService {
	private EmpDao dao;
	
	@Resource(name="empDao")
	public void setEmpDao(EmpDao dao){
		this.dao=dao;
	}
	

	@Override
	public Emp getEmpDetails(int empId) throws EmpException {
	
		return dao.getEmpDetails(empId);
	}

	@Override
	public List<Emp> getAllEmp() throws EmpException {
		
		return dao.getAllEmp();
	}

	@Override
	public Emp insertNewEmp(Emp emp) throws EmpException, RollbackException {
		
		return dao.insertNewEmp(emp);
	}

	@Override
	public Emp updateEmp(Emp emp) throws EmpException, RollbackException {
		
		return dao.updateEmp(emp);
	}


	@Override
	public boolean deleteNewEmp(int empId) throws EmpException,
			RollbackException {
		
		return dao.deleteNewEmp(empId);
	}

}
